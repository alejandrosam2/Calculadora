
/**
 *
 * @author alejandrosalmon
 */
public class ExcepcionColeccionVacia extends RuntimeException {

    public ExcepcionColeccionVacia(String message) {
        super(message);
    }
    
}
